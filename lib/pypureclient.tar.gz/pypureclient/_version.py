__name__ = 'py-pure-client'
__version__ = '1.60.0'
__default_user_agent__ = 'pure/{}/{}'.format(__name__, __version__)